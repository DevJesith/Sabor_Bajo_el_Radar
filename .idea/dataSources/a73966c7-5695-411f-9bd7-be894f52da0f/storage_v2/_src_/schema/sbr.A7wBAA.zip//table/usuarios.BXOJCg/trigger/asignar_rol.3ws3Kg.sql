create definer = root@localhost trigger asignar_rol
    after insert
    on usuarios
    for each row
BEGIN
    -- Si el usuario es cliente, se inserta en la tabla cliente
    IF NEW.rol = 'cliente' THEN
        INSERT INTO cliente (usuario_id) VALUES (NEW.id);
    
    -- Si el usuario es vendedor, se inserta en la tabla vendedor
    ELSEIF NEW.rol = 'vendedor' THEN
        INSERT INTO vendedor (usuario_id, negocio_id) 
        VALUES (NEW.id, 1); -- 1 es un ID temporal, puedes cambiarlo dinámicamente
    -- Si el usuario es domiciliario, se inserta en la tabla domiciliario
    ELSEIF NEW.rol = 'domiciliario' THEN
        INSERT INTO domiciliario (usuario_id, medio_transporte_id) 
        VALUES (NEW.id, 1); -- 1 es un ID temporal, puedes cambiarlo dinámicamente
    END IF;
END;

